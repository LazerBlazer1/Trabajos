package com.example.sumarapida

import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    // creacion de variables
    private lateinit var numbersText: TextView
    private lateinit var answerInput: EditText
    private lateinit var submitBtn: Button
    private lateinit var scoreText: TextView
    private lateinit var livesText: TextView
    private lateinit var timerText: TextView
    private lateinit var levelText: TextView

    private var num1 = 0
    private var num2 = 0
    private var score = 0
    private var lives = 3
    private var level = 1
    private var timer: CountDownTimer? = null
    private var timeLimit = 10000L // 10 segundos aprox

// creacion de variables con función incorporada

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        numbersText = findViewById(R.id.numbersText)
        answerInput = findViewById(R.id.answerInput)
        submitBtn = findViewById(R.id.submitBtn)
        scoreText = findViewById(R.id.scoreText)
        livesText = findViewById(R.id.livesText)
        timerText = findViewById(R.id.timerText)
        levelText = findViewById(R.id.levelText)

        submitBtn.setOnClickListener {
            checkAnswer()
        }

        startNewRound()
    }
// Nuevo round
    private fun startNewRound() {
        answerInput.text.clear()
        generateNumbers()
        startTimer()
    }
// Random numbers para suma
    private fun generateNumbers() {
        val max = level * 10
        num1 = Random.nextInt(1, max)
        num2 = Random.nextInt(1, max)
        numbersText.text = "$num1 + $num2"
    }
// Empezada de tiempo
    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(timeLimit, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timerText.text = "Tiempo: ${millisUntilFinished / 1000}"
            }

            override fun onFinish() {
                loseLife()
            }
        }.start()
    }
// Sistema de puntos
    private fun checkAnswer() {
        val answer = answerInput.text.toString().toIntOrNull()
        if (answer == num1 + num2) {
            score += 5
            scoreText.text = "Puntos: $score"

            if (score % 50 == 0) {
                level++
                levelText.text = "Nivel: $level"
            }

            startNewRound()
        } else {
            loseLife()
        }
    }
// Funcion de perdida de vida
    private fun loseLife() {
        lives--
        livesText.text = "Vidas: $lives"
        if (lives <c 0) {
            gameOver()
        } else {
            startNewRound()
        }
    }<
// Funcion de gameover
    private fun gameOver() {
        timer?.cancel()
        Toast.makeText(this, "¡Juego terminado!, tus puntos: Puntos: $score", Toast.LENGTH_LONG).show()
        score = 0
        lives = 3
        level = 1
        scoreText.text = "Puntos: $score"
        livesText.text = "Vidas: $lives"
        levelText.text = "Nivel: $level"
        startNewRound()
    }
// Timer acabado
    override fun onDestroy() {
        super.onDestroy()
        timer?.cancel()
    }
}
