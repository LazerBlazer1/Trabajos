package com.example.adivinanumero

import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random
import android.media.MediaPlayer

class MainActivity : AppCompatActivity() {

    private lateinit var numberInput: EditText
    private lateinit var rollButton: Button
    private lateinit var diceImage: ImageView
    private lateinit var resultText: TextView
    private var score = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        numberInput = findViewById(R.id.numberInput)
        rollButton = findViewById(R.id.rollButton)
        diceImage = findViewById(R.id.diceImage)
        resultText = findViewById(R.id.resultText)

        rollButton.setOnClickListener {
            try {
                val guessedNumber = numberInput.text.toString().toIntOrNull()

                if (guessedNumber == null || guessedNumber !in 1..6) {
                    Toast.makeText(this, "Ingresa un número válido del 1 al 6", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                // Reproducir sonido del dado
                val mediaPlayer = MediaPlayer.create(this, R.raw.dado)
                mediaPlayer.start()

                // Mostrar dado vacío mientras "lanza"
                diceImage.setImageResource(R.drawable.dado0)
                resultText.text = "Lanzando dado..."

                object : CountDownTimer(1500, 1000) {
                    override fun onTick(millisUntilFinished: Long) {}

                    override fun onFinish() {
                        try {
                            val rolledNumber = Random.nextInt(1, 7)

                            val drawableId = when (rolledNumber) {
                                1 -> R.drawable.dado1
                                2 -> R.drawable.dado2
                                3 -> R.drawable.dado3
                                4 -> R.drawable.dado4
                                5 -> R.drawable.dado5
                                6 -> R.drawable.dado6
                                else -> R.drawable.dado0
                            }

                            diceImage.setImageResource(drawableId)

                            if (guessedNumber == rolledNumber) {
                                score++
                                resultText.text = "¡Ganaste! Era el $rolledNumber\nPuntos: $score"
                            } else {
                                resultText.text = "Fallaste. Era el $rolledNumber\nPuntos: $score"
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                            Log.e("AdivinaNumero", "Error al mostrar dado: ${e.message}")
                            Toast.makeText(this@MainActivity, "Error al mostrar el dado", Toast.LENGTH_SHORT).show()
                            diceImage.setImageResource(R.drawable.dado0)
                        }
                    }
                }.start()

            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("AdivinaNumero", "Error inesperado: ${e.message}")
                Toast.makeText(this, "Ocurrió un error inesperado", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
